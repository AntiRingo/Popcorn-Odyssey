'use strict';
const guestVariantCount=5;
const guestStages=[
  {
    "name": "普通街坊",
    "names": [
      "晚班职员",
      "末班车乘客",
      "街角住客",
      "雨夜访客",
      "货站看守"
    ],
    "note": "灯光下的普通顾客。他们只是来买一份热食。",
    "tells": [
      "眼镜后的目光平常，衣领略旧。",
      "眉眼疲惫，赶在末班车前到店。",
      "脸部比例自然，习惯穿灰色外套。",
      "外套带着夜雨，神情安静。",
      "工作服胸前别着旧铜牌，手上留着劳动的痕迹。"
    ]
  },
  {
    "name": "细微违和",
    "names": [
      "偏瞳熟客",
      "鳃痕乘客",
      "银线访客",
      "凝露住客",
      "长指来客"
    ],
    "note": "看起来仍然是人类，只有某个细节偏离常态。",
    "tells": [
      "伪人征兆：一侧瞳孔偏离眼白中心，始终盯着你的身后。",
      "深海征兆：耳旁多了三道很浅的鳃痕。",
      "星外征兆：额角浮出细银线，像一枚埋在皮下的芯片。",
      "胶质征兆：太阳穴挂着一滴绿色凝珠，皮肤没有湿痕。",
      "袖口下的手指略长，关节的位置有些奇怪。"
    ]
  },
  {
    "name": "异相显露",
    "names": [
      "拉链嘴职员",
      "涡眼乘客",
      "触角收讯者",
      "流颊住客",
      "钩指模仿者"
    ],
    "note": "异常集中在一个器官，各自显露不同来源。",
    "tells": [
      "伪人化：嘴唇被一条横向拉链取代，中间有金属拉环。",
      "克苏鲁化：左眼变成青色旋涡，虹膜一圈圈向内盘绕。",
      "外星人化：发际伸出两根细长感应触角，末端泛着紫光。",
      "史莱姆化：一侧脸颊像蜡一样流下，露出半透明气泡。",
      "袖口伸出弯钩状手指。可能突然扑向柜台；抬臂并泛红时须拿枪反击。"
    ]
  },
  {
    "name": "形态分岔",
    "names": [
      "悬面职员",
      "伞鳃朝圣者",
      "棱晶旅客",
      "浮眼胶客",
      "裂喉伏客"
    ],
    "note": "人形结构开始改变，衣着却依然整齐。",
    "tells": [
      "伪人化：一张完整面具悬在黑色头腔前，由细线固定。",
      "克苏鲁化：扇状鳃冠从两颊展开，喉部留着一枚闭合的贝壳。",
      "外星人化：头部形成紫色几何棱晶，三枚金色视觉节点垂直排列。",
      "史莱姆化：透明水滴头部里，两只眼球分离漂浮，嘴巴沉到了底部。",
      "下颌张成纵向暗口。可能伏低身体后突袭，预警动作时可用猎枪逼退。"
    ]
  },
  {
    "name": "非人来客",
    "names": [
      "折面替身",
      "冠须祭司",
      "环轨观测者",
      "星核原浆",
      "酸冠潜客"
    ],
    "note": "伪装已经失去意义。他们仍礼貌地等着自己的订单。",
    "tells": [
      "伪人化：脸被折成四张朝向不同角度的纸片，每片只有一个五官。",
      "克苏鲁化：长须形成下垂触手冠，额头横开金色巨眼。",
      "外星人化：无脸的黑色球体被倾斜轨道环包围，环上悬着三枚卫星。",
      "史莱姆化：头颈融成紫红胶团，星形核心和细小亮点悬浮其中。",
      "头顶酸绿色冠囊收缩。可能向柜台喷吐，冠囊闪红时可用猎枪打断。"
    ]
  }
];
const guestEntryCount=guestStages.reduce((sum,stage)=>sum+stage.names.length,0);
const ingredientEntries={
 corn:{tag:'基础原料 / A-01',description:'紧密排列的金色玉米粒。爆开前，它们看起来都很安静。',usage:'抓住玉米来回摇晃脱粒。每批使用 1 份玉米，再加入机器。'},
 butter:{tag:'基础原料 / A-02',description:'切成小块的淡黄奶油。加热后，熟悉的香气会盖住街道的潮湿。',usage:'每台机器每批消耗 1 份，和玉米一起爆制 6 秒。'},
 caramel:{tag:'甜味佐料 / B-01',description:'琥珀色糖浆，带一点焦苦。记得核对订单。',usage:'装盒后撒入 1 份，制成焦糖爆米花；正确订单售价 24 ◈。'},
 cheese:{tag:'咸味佐料 / B-02',description:'细腻的金黄色粉末。包装上写着：请保持干燥。',usage:'装盒后撒入 1 份，制成芝士爆米花；正确订单售价 24 ◈。'},
 chili:{tag:'辛辣佐料 / B-03',description:'暗红色的干燥碎末。即使最沉默的顾客，也会注意到它。',usage:'装盒后撒入 1 份，制成辣椒爆米花；正确订单售价 26 ◈。'}
};

const goods={corn:{name:'玉米',icon:'🌽',qty:5,cost:12},butter:{name:'奶油',icon:'▰',qty:5,cost:10},caramel:{name:'焦糖',icon:'▰',qty:4,cost:8},cheese:{name:'芝士',icon:'◭',qty:4,cost:8},chili:{name:'辣椒',icon:'♨',qty:4,cost:8}};

const upgradeCatalog={
 shell:{name:'自动脱粒臂',icon:'⚙',cost:65,description:'每秒脱粒一次并自动收集到原料盒，备好一批后停止。消耗库存玉米。'},
 feed:{name:'自动加料管',icon:'⇣',cost:85,description:'把脱好的玉米依次送入空闲机器，并自动加入库存奶油。'},
 cook:{name:'自动点火器',icon:'♨',cost:100,description:'机器原料齐全后自动爆制，6 秒出锅。'},
 procure:{name:'自动采购员',icon:'↻',cost:90,description:'库存不足 3 份时自动下单；优先玉米与奶油，余额不足时等待，配送不重复。'},
 prepTables:{name:'增设脱粒工作台',icon:'⚒',cost:80,description:'增加一个独立备料台，最多 4 台；自动脱粒升级覆盖全部工作台。'},
 packTables:{name:'增设包装台',icon:'▤',cost:80,description:'增加一个独立纸盒位，最多 4 台；可同时保存不同口味的成品。'},
 autoPack:{name:'自动装盒臂',icon:'⇧',cost:110,description:'将任意已出锅机器的爆米花装入空包装台；调味与交付仍由你操作。'},
 machines:{name:'增设爆米花机',icon:'▣',cost:120,description:'增加一台独立生产的机器，可同时爆制。最多 4 台。'}
};

// Price settings are shared by all saves on this browser origin.
const PRICE_CONFIG_KEY='popcorn-odyssey-prices-v1';
const PRICE_MAX=1000000;
const priceCatalogs={upgrades:upgradeCatalog,materials:goods};
const defaultPrices=Object.fromEntries(Object.entries(priceCatalogs).map(([group,items])=>[group,Object.fromEntries(Object.entries(items).map(([key,item])=>[key,item.cost]))]));
function validBasePrice(value){return Number.isInteger(value)&&value>=0&&value<=PRICE_MAX;}
function normalizePrices(raw){
 return Object.fromEntries(Object.entries(defaultPrices).map(([group,items])=>[group,Object.fromEntries(Object.entries(items).map(([key,value])=>[key,validBasePrice(raw?.[group]?.[key])?raw[group][key]:value]))]));
}
function applyPrices(prices){for(const [group,items] of Object.entries(priceCatalogs))for(const [key,item] of Object.entries(items))item.cost=prices[group][key];}
let priceConfigLoadFailed=false;
try{applyPrices(normalizePrices(JSON.parse(localStorage.getItem(PRICE_CONFIG_KEY))));}catch{priceConfigLoadFailed=true;}
function savePrices(prices){
 const normalized=normalizePrices(prices);
 localStorage.setItem(PRICE_CONFIG_KEY,JSON.stringify(normalized));
 applyPrices(normalized);
 priceConfigLoadFailed=false;
}
